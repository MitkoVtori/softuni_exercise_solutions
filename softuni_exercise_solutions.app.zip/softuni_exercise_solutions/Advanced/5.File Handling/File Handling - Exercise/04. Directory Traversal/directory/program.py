print("I'm a Python Program")
print("It's nice to meet you!")