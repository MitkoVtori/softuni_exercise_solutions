function ChangeColor() {
 document.getElementById("main").style.color = "purple";
}