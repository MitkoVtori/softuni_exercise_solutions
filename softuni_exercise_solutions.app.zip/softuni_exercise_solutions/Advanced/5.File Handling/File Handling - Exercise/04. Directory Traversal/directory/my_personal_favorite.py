"HEllO WORLD!"
print("Please give me good grade!")
print("Love <3 :)")