class TooManyInvalidTriesError(Exception):
    pass
